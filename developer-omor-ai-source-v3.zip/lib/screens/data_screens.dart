import 'package:flutter/material.dart';
import '../services/app_state.dart';

class MemoryScreen extends StatefulWidget {
  const MemoryScreen({super.key});
  @override
  State<MemoryScreen> createState() => _MemoryScreenState();
}

class _MemoryScreenState extends State<MemoryScreen> {
  final ctl = TextEditingController();

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _add() {
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    appState.addMemory(t);
    ctl.clear();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Memory Manager'), backgroundColor: const Color(0xFF090B14)),
    body: ListenableBuilder(
      listenable: appState,
      builder: (context, _) => Column(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Text(
            'এখানকার তথ্য AI সবসময় মনে রাখবে। চ্যাটে "মনে রাখো..." বললেও এখানে জমা হবে।',
            style: TextStyle(color: Colors.white54),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: ctl,
                onSubmitted: (_) => _add(),
                decoration: const InputDecoration(hintText: 'নতুন কিছু মনে রাখতে বলো...'),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _add, icon: const Icon(Icons.add)),
          ]),
        ),
        Expanded(
          child: appState.memories.isEmpty
              ? const Center(child: Text('কোনো মেমোরি নেই', style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: appState.memories.length,
                  itemBuilder: (context, i) => Card(
                    color: const Color(0xFF141827),
                    child: ListTile(
                      title: Text(appState.memories[i]),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => appState.removeMemory(i),
                      ),
                    ),
                  ),
                ),
        ),
      ]),
    ),
  );
}

class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key});

  Future<void> _add(BuildContext context) async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('নতুন কন্টাক্ট'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(hintText: 'নাম')),
          const SizedBox(height: 10),
          TextField(
            controller: phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(hintText: 'নম্বর (যেমন 017XXXXXXXX)'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('সেভ')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty && phone.text.trim().isNotEmpty) {
      await appState.addContact(name.text, phone.text);
    }
    name.dispose();
    phone.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Contacts'), backgroundColor: const Color(0xFF090B14)),
    floatingActionButton: FloatingActionButton(
      onPressed: () => _add(context),
      child: const Icon(Icons.person_add_alt_1),
    ),
    body: ListenableBuilder(
      listenable: appState,
      builder: (context, _) => Column(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Text(
            'এখানে নাম ও নম্বর সেভ করলে AI কে বলতে পারবে: "রহিমকে WhatsApp এ লেখো...", "করিমকে কল দাও"।',
            style: TextStyle(color: Colors.white54),
          ),
        ),
        Expanded(
          child: appState.contacts.isEmpty
              ? const Center(child: Text('কোনো কন্টাক্ট নেই', style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                  itemCount: appState.contacts.length,
                  itemBuilder: (context, i) {
                    final c = appState.contacts[i];
                    return Card(
                      color: const Color(0xFF141827),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFF302B59),
                          child: Icon(Icons.person, color: Color(0xFFB8AEFF)),
                        ),
                        title: Text(c['name'] ?? ''),
                        subtitle: Text(c['phone'] ?? '', style: const TextStyle(color: Colors.white54)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => appState.removeContact(i),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    ),
  );
}
