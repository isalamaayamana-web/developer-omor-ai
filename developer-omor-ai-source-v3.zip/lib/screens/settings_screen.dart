import 'package:flutter/material.dart';
import '../services/app_state.dart';
import 'ai_settings_screen.dart';
import 'app_shell.dart';
import 'data_screens.dart';
import 'developer_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _push(BuildContext context, Widget page) =>
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));

  void _language(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('AI কোন ভাষায় উত্তর দেবে?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 14),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'auto', label: Text('Auto')),
                  ButtonSegment(value: 'bn', label: Text('বাংলা')),
                  ButtonSegment(value: 'en', label: Text('English')),
                ],
                selected: {appState.language},
                onSelectionChanged: (s) => appState.setLanguage(s.first),
              ),
              const SizedBox(height: 10),
              const Text(
                'Auto = তুমি যে ভাষায় লিখবে সেই ভাষায়। Voice এ বাংলা/English আলাদা বেছে নিতে পারবে।',
                style: TextStyle(color: Colors.white54),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> _clearChat(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('চ্যাট হিস্ট্রি মুছবে?'),
        content: const Text('সব পুরনো চ্যাট এই ফোন থেকে মুছে যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('না')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('মুছো')),
        ],
      ),
    );
    if (ok == true) await appState.clearChat();
  }

  void _info(BuildContext context, String title, String body) {
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('ঠিক আছে'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Column(children: [
    const PageHeader(subtitle: 'CONFIGURATION'),
    Expanded(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        _SettingTile(
          icon: Icons.badge_outlined,
          title: 'Developer Information',
          subtitle: 'Omor • Telegram, TikTok, GitHub',
          onTap: () => _push(context, const DeveloperScreen()),
        ),
        _SettingTile(
          icon: Icons.smart_toy_outlined,
          title: 'AI Providers & Keys',
          subtitle: 'Gemini, Groq, OpenRouter, Grok — ফ্রি API key',
          onTap: () => _push(context, const AiSettingsScreen()),
        ),
        _SettingTile(
          icon: Icons.volume_up_outlined,
          title: 'Voice & Language',
          subtitle: 'Bangla / English, voice preferences',
          onTap: () => _language(context),
        ),
        _SettingTile(
          icon: Icons.memory,
          title: 'Memory',
          subtitle: 'AI যা মনে রাখবে',
          onTap: () => _push(context, const MemoryScreen()),
        ),
        _SettingTile(
          icon: Icons.contacts_outlined,
          title: 'Contacts',
          subtitle: 'WhatsApp / SMS / কলের জন্য নাম ও নম্বর',
          onTap: () => _push(context, const ContactsScreen()),
        ),
        _SettingTile(
          icon: Icons.storage_outlined,
          title: 'Data & Memory',
          subtitle: 'চ্যাট হিস্ট্রি মুছে ফেলো',
          onTap: () => _clearChat(context),
        ),
        _SettingTile(
          icon: Icons.shield_outlined,
          title: 'Privacy & Security',
          subtitle: 'Permissions, device access and safety',
          onTap: () => _info(
            context,
            'Privacy & Security',
            'API key, চ্যাট, মেমোরি ও কন্টাক্ট শুধু এই ফোনে সেভ থাকে।\n\n'
                'তুমি প্রশ্ন করলে সেটা তোমার বেছে নেওয়া AI সার্ভিসে (Gemini, Groq ইত্যাদি) পাঠানো হয়।\n\n'
                'WhatsApp/SMS/কল নিজে নিজে হয় না: অ্যাপ শুধু খসড়া সহ অ্যাপ খুলে দেয়, Send তুমি চাপো।\n\n'
                'মাইক্রোফোন শুধু Voice ব্যবহারের সময় লাগে।',
          ),
        ),
        _SettingTile(
          icon: Icons.info_outline,
          title: 'About',
          subtitle: 'DEVELOPER OMOR AI • 1.0.0',
          onTap: () => _info(
            context,
            'DEVELOPER OMOR AI',
            'Version 1.0.0\nDeveloped by Omor\n\nচ্যাট, ভয়েস, ছবি/ডকুমেন্ট বিশ্লেষণ, পোস্ট ও মেসেজ তৈরি।',
          ),
        ),
      ]),
    ),
  ]);
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF141827),
    child: ListTile(
      onTap: onTap,
      leading: Icon(icon, color: const Color(0xFFB8AEFF)),
      title: Text(title),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54)),
      trailing: const Icon(Icons.chevron_right),
    ),
  );
}
