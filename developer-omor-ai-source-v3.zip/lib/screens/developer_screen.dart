import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class DeveloperScreen extends StatelessWidget {
  const DeveloperScreen({super.key});

  static const _card = Color(0xFF141827);
  static const _accent = Color(0xFF8B7CFF);
  static const _soft = Color(0xFFB8AEFF);

  Future<void> _open(BuildContext context, String url) async {
    try {
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (ok) return;
    } catch (_) {}
    await Clipboard.setData(ClipboardData(text: url));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('লিংক খোলা যায়নি, কপি করা হয়েছে')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Developer Information'),
        backgroundColor: const Color(0xFF090B14),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 8),
          Center(
            child: Container(
              width: 140,
              height: 140,
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Color(0xFF8B7CFF), Color(0xFF42C9C0)]),
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/developer.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stack) => const ColoredBox(
                    color: _card,
                    child: Icon(Icons.person, size: 70, color: _soft),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Center(
            child: Text('Omor', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 6),
          const Center(
            child: Text('Developer • AI App Builder', style: TextStyle(color: _soft)),
          ),
          const SizedBox(height: 22),
          const Card(
            color: _card,
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'DEVELOPER OMOR AI হলো Omor-এর তৈরি একটি ব্যক্তিগত AI অ্যাসিস্ট্যান্ট। '
                'বাংলা ও English দুই ভাষাতেই চ্যাট, ভয়েস এবং স্মার্ট টুলস নিয়ে অ্যাপটি '
                'ধাপে ধাপে আরও উন্নত করা হচ্ছে।',
                style: TextStyle(height: 1.6, color: Colors.white70),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 8),
            child: Text('Connect with me', style: TextStyle(fontWeight: FontWeight.w700, color: _accent)),
          ),
          _LinkTile(
            icon: Icons.send,
            title: 'Telegram Channel',
            subtitle: 't.me/fishing8886',
            onTap: () => _open(context, 'https://t.me/fishing8886'),
          ),
          _LinkTile(
            icon: Icons.person_outline,
            title: 'Telegram (Personal)',
            subtitle: '@OmorCyber',
            onTap: () => _open(context, 'https://t.me/OmorCyber'),
          ),
          _LinkTile(
            icon: Icons.music_note,
            title: 'TikTok',
            subtitle: '@uwsomor7',
            onTap: () => _open(context, 'https://www.tiktok.com/@uwsomor7'),
          ),
          _LinkTile(
            icon: Icons.code,
            title: 'GitHub',
            subtitle: 'omorxdev',
            onTap: () => _open(context, 'https://github.com/omorxdev'),
          ),
        ],
      ),
    );
  }
}

class _LinkTile extends StatelessWidget {
  const _LinkTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        color: const Color(0xFF141827),
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF302B59),
            child: Icon(icon, color: const Color(0xFFB8AEFF)),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54)),
          trailing: const Icon(Icons.open_in_new, size: 18),
        ),
      );
}
