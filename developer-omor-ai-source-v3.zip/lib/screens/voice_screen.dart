import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../services/actions.dart';
import '../services/ai_service.dart';
import '../services/app_state.dart';
import '../services/speech_util.dart';
import '../widgets/common.dart';
import 'app_shell.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});
  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final stt = SpeechToText();
  final tts = FlutterTts();
  final history = <AiMessage>[];
  bool ready = false;
  bool listening = false;
  bool thinking = false;
  bool speaking = false;
  String heard = '';
  String reply = '';
  List<AiAction> actions = [];
  String locale = 'bn_BD';

  @override
  void initState() {
    super.initState();
    tts.setCompletionHandler(() {
      if (mounted) setState(() => speaking = false);
    });
    tts.setCancelHandler(() {
      if (mounted) setState(() => speaking = false);
    });
  }

  @override
  void dispose() {
    stt.cancel();
    tts.stop();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (thinking) return;
    if (speaking) {
      await tts.stop();
      if (mounted) setState(() => speaking = false);
      return;
    }
    if (listening) {
      await stt.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    if (!ready) {
      ready = await stt.initialize(
        onStatus: (s) {
          if ((s == 'done' || s == 'notListening') && mounted && listening) {
            setState(() => listening = false);
          }
        },
        onError: (e) {
          if (mounted) {
            setState(() {
              listening = false;
              reply = 'মাইক্রোফোন সমস্যা: ${e.errorMsg}';
            });
          }
        },
      );
    }
    if (!ready) {
      if (mounted) setState(() => reply = 'মাইক্রোফোনের অনুমতি দিন (ফোন Settings > Apps > Omor AI > Permissions)');
      return;
    }
    setState(() {
      listening = true;
      heard = '';
      reply = '';
      actions = [];
    });
    await stt.listen(
      onResult: (r) {
        if (!mounted) return;
        setState(() => heard = r.recognizedWords);
        if (r.finalResult && r.recognizedWords.trim().isNotEmpty && !thinking) {
          _ask(r.recognizedWords.trim());
        }
      },
      localeId: locale,
      listenFor: const Duration(seconds: 40),
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> _ask(String text) async {
    setState(() {
      thinking = true;
      listening = false;
      reply = '';
      actions = [];
    });
    history.add(AiMessage('user', text));
    String spoken = '';
    try {
      final recent = history.length > 12
          ? history.sublist(history.length - 12)
          : List<AiMessage>.from(history);
      while (recent.isNotEmpty && recent.first.role != 'user') {
        recent.removeAt(0);
      }
      final raw = await AiService.ask(
        recent,
        system: '${buildSystemPrompt()}\nThis is a VOICE conversation: answer in 1-3 short spoken sentences, no markdown, no lists.',
        search: appState.webSearch,
      );
      final p = parseReply(raw);
      history.add(AiMessage('assistant', p.text));
      spoken = p.text;
      if (mounted) setState(() {
            reply = p.text;
            actions = p.actions;
          });
    } on AiException catch (e) {
      if (mounted) {
        setState(() => reply = e.message == AiService.noKey
            ? 'আগে Settings → AI Providers & Keys এ API key দিন।'
            : e.message);
      }
    } catch (e) {
      if (mounted) setState(() => reply = 'সমস্যা হয়েছে: $e');
    }
    if (mounted) setState(() => thinking = false);
    if (spoken.isNotEmpty && mounted) {
      setState(() => speaking = true);
      await speakText(tts, spoken);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = listening
        ? 'শুনছি...'
        : thinking
            ? 'ভাবছি...'
            : speaking
                ? 'বলছি... (থামাতে ট্যাপ করো)'
                : 'Omor AI Voice';
    return Column(children: [
      const AiStatusHeader(),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        ChoiceChip(
          label: const Text('বাংলা'),
          selected: locale == 'bn_BD',
          onSelected: (_) => setState(() => locale = 'bn_BD'),
        ),
        const SizedBox(width: 8),
        ChoiceChip(
          label: const Text('English'),
          selected: locale == 'en_US',
          onSelected: (_) => setState(() => locale = 'en_US'),
        ),
      ]),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            const SizedBox(height: 12),
            Container(
              width: 170,
              height: 170,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [Color(0xFF5E50B8), Color(0xFF151A2B)]),
                boxShadow: [BoxShadow(color: Color(0x3D8B7CFF), blurRadius: 55, spreadRadius: 8)],
              ),
              child: Icon(listening ? Icons.mic : Icons.graphic_eq, size: 76, color: Colors.white),
            ),
            const SizedBox(height: 22),
            Text(status, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            if (heard.isNotEmpty)
              Text('তুমি: $heard', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
            if (reply.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF171C2B), borderRadius: BorderRadius.circular(16)),
                child: RichReply(reply),
              ),
            ],
            for (final a in actions) ActionCard(action: a),
          ]),
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(bottom: 24, top: 8),
        child: FilledButton.icon(
          onPressed: _toggle,
          icon: Icon(listening ? Icons.stop : (speaking ? Icons.volume_off : Icons.mic)),
          label: Text(listening ? 'Stop listening' : (speaking ? 'থামাও' : 'Start voice chat')),
          style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18)),
        ),
      ),
    ]);
  }
}
