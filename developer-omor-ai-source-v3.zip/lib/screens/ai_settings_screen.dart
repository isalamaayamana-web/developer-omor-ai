import 'package:flutter/material.dart';
import '../services/app_state.dart';

class AiSettingsScreen extends StatefulWidget {
  const AiSettingsScreen({super.key});
  @override
  State<AiSettingsScreen> createState() => _AiSettingsScreenState();
}

class _AiSettingsScreenState extends State<AiSettingsScreen> {
  final keyCtl = <String, TextEditingController>{};
  final modelCtl = <String, TextEditingController>{};
  final shown = <String, bool>{};
  late final TextEditingController baseCtl;
  late final TextEditingController nameCtl;

  @override
  void initState() {
    super.initState();
    for (final p in providerList) {
      keyCtl[p.id] = TextEditingController(text: appState.keys[p.id] ?? '');
      modelCtl[p.id] = TextEditingController(text: appState.models[p.id] ?? '');
    }
    baseCtl = TextEditingController(text: appState.customBase);
    nameCtl = TextEditingController(text: appState.userName);
  }

  @override
  void dispose() {
    for (final c in keyCtl.values) {
      c.dispose();
    }
    for (final c in modelCtl.values) {
      c.dispose();
    }
    baseCtl.dispose();
    nameCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI Providers & Keys'), backgroundColor: const Color(0xFF090B14)),
    body: ListenableBuilder(
      listenable: appState,
      builder: (context, _) => ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'যেকোনো এক বা একাধিক ফ্রি API key বসাও। প্রধান সার্ভিসে সমস্যা হলে (যেমন লিমিট শেষ) অ্যাপ নিজে থেকে অন্য সার্ভিসে চেষ্টা করবে। key শুধু এই ফোনে সেভ থাকে।',
          style: TextStyle(color: Colors.white54, height: 1.5),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: nameCtl,
          onChanged: appState.setUserName,
          decoration: const InputDecoration(hintText: 'তোমার নাম (AI যাতে নাম ধরে ডাকে)'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Web Search (Gemini)'),
          subtitle: const Text('Gemini দিয়ে ইন্টারনেট থেকে নতুন তথ্য খুঁজবে', style: TextStyle(color: Colors.white54)),
          value: appState.webSearch,
          onChanged: appState.setWebSearch,
        ),
        for (final p in providerList)
          Card(
            color: const Color(0xFF141827),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                  if (appState.preferred == p.id)
                    const Chip(label: Text('প্রধান'), avatar: Icon(Icons.check, size: 16))
                  else
                    TextButton(onPressed: () => appState.setPreferred(p.id), child: const Text('প্রধান করো')),
                ]),
                Text(p.hint, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                const SizedBox(height: 10),
                TextField(
                  controller: keyCtl[p.id],
                  obscureText: !(shown[p.id] ?? false),
                  autocorrect: false,
                  enableSuggestions: false,
                  onChanged: (v) => appState.setKey(p.id, v),
                  decoration: InputDecoration(
                    hintText: 'API key',
                    suffixIcon: IconButton(
                      icon: Icon((shown[p.id] ?? false) ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => setState(() => shown[p.id] = !(shown[p.id] ?? false)),
                    ),
                  ),
                ),
                if (p.id == 'custom') ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: baseCtl,
                    autocorrect: false,
                    onChanged: appState.setCustomBase,
                    decoration: const InputDecoration(hintText: 'Base URL (যেমন https://api.example.com/v1)'),
                  ),
                ],
                const SizedBox(height: 10),
                TextField(
                  controller: modelCtl[p.id],
                  autocorrect: false,
                  onChanged: (v) => appState.setModel(p.id, v),
                  decoration: InputDecoration(
                    hintText: p.defaultModel.isEmpty ? 'Model নাম' : 'Model (ডিফল্ট: ${p.defaultModel})',
                  ),
                ),
              ]),
            ),
          ),
      ]),
    ),
  );
}
