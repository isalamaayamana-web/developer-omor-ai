import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import '../services/actions.dart';
import '../services/ai_service.dart';
import '../services/app_state.dart';
import '../services/attachments.dart';
import '../services/speech_util.dart';
import '../widgets/common.dart';
import 'ai_settings_screen.dart';
import 'app_shell.dart';

class ChatMsg {
  ChatMsg(
    this.role,
    this.text, {
    this.aiText,
    this.actions = const [],
    this.attachName,
    this.attachBytes,
    this.attachMime,
    this.isError = false,
    this.needsKey = false,
  });
  final String role;
  final String text;
  final String? aiText;
  final List<AiAction> actions;
  final String? attachName;
  final Uint8List? attachBytes;
  final String? attachMime;
  final bool isError;
  final bool needsKey;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final scroll = ScrollController();
  final tts = FlutterTts();
  final msgs = <ChatMsg>[];
  bool sending = false;
  Attachment? _att;
  int _seenResets = 0;

  static const _suggestions = [
    'একটা Facebook পোস্ট লিখে দাও',
    'আজকের জন্য একটা প্ল্যান বানাও',
    'আমাকে একটা মজার আইডিয়া দাও',
  ];

  @override
  void initState() {
    super.initState();
    _seenResets = appState.chatResets;
    for (final m in appState.chat) {
      msgs.add(ChatMsg(m['role'] ?? 'user', m['text'] ?? ''));
    }
    appState.addListener(_onState);
  }

  void _onState() {
    if (appState.chatResets != _seenResets) {
      _seenResets = appState.chatResets;
      if (mounted) setState(() => msgs.clear());
    }
  }

  @override
  void dispose() {
    appState.removeListener(_onState);
    controller.dispose();
    scroll.dispose();
    tts.stop();
    super.dispose();
  }

  void _persist() {
    appState.saveChat(
      msgs
          .where((m) => !m.isError && !m.needsKey)
          .map((m) => {'role': m.role, 'text': m.text})
          .toList(),
    );
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(
          scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_outlined), title: const Text('গ্যালারি থেকে ছবি'), onTap: () => Navigator.pop(c, 'gallery')),
          ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('ক্যামেরা'), onTap: () => Navigator.pop(c, 'camera')),
          ListTile(leading: const Icon(Icons.description_outlined), title: const Text('ফাইল (PDF, TXT, CSV...)'), onTap: () => Navigator.pop(c, 'file')),
        ]),
      ),
    );
    if (choice == null) return;
    Attachment? a;
    try {
      if (choice == 'gallery') a = await pickImageAttachment(ImageSource.gallery);
      if (choice == 'camera') a = await pickImageAttachment(ImageSource.camera);
      if (choice == 'file') a = await pickFileAttachment();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ফাইল নেওয়া যায়নি')));
      }
    }
    if (a != null && mounted) setState(() => _att = a);
  }

  Future<void> send() async {
    final typed = controller.text.trim();
    final att = _att;
    if ((typed.isEmpty && att == null) || sending) return;
    var prompt = typed;
    final attText = att?.text;
    if (attText != null) {
      prompt = '$attText\n\n${typed.isEmpty ? 'এই ফাইলটা পড়ে সারাংশ দাও।' : typed}';
    } else if (prompt.isEmpty) {
      prompt = 'এই ফাইল/ছবিটা বিশ্লেষণ করো।';
    }
    final userMsg = ChatMsg(
      'user',
      typed.isEmpty ? (att != null ? '📎 ${att.name}' : '') : typed,
      aiText: prompt,
      attachName: att?.name,
      attachBytes: att?.bytes,
      attachMime: att?.mime,
    );
    setState(() {
      msgs.add(userMsg);
      sending = true;
      _att = null;
      controller.clear();
    });
    _scrollDown();
    try {
      final real = msgs.where((m) => !m.isError && !m.needsKey).toList();
      final recent = real.length > 20 ? real.sublist(real.length - 20) : real;
      final hist = <AiMessage>[];
      for (var i = 0; i < recent.length; i++) {
        final m = recent[i];
        final isLast = i == recent.length - 1;
        hist.add(AiMessage(
          m.role,
          m.aiText ?? m.text,
          data: isLast ? m.attachBytes : null,
          mime: isLast ? m.attachMime : null,
        ));
      }
      while (hist.isNotEmpty && hist.first.role != 'user') {
        hist.removeAt(0);
      }
      final raw = await AiService.ask(hist, system: buildSystemPrompt(), search: appState.webSearch);
      final parsed = parseReply(raw);
      if (mounted) {
        setState(() => msgs.add(ChatMsg(
              'assistant',
              parsed.text.isEmpty ? '✅' : parsed.text,
              actions: parsed.actions,
            )));
      }
    } on AiException catch (e) {
      if (mounted) {
        setState(() {
          if (e.message == AiService.noKey) {
            msgs.add(ChatMsg(
              'assistant',
              'এখনো কোনো API key দেওয়া হয়নি। Settings → AI Providers & Keys এ গিয়ে Gemini বা Groq এর ফ্রি key বসান, তারপর আবার চেষ্টা করুন।',
              needsKey: true,
            ));
          } else {
            msgs.add(ChatMsg('assistant', e.message, isError: true));
          }
        });
      }
    } catch (e) {
      if (mounted) setState(() => msgs.add(ChatMsg('assistant', 'কিছু একটা সমস্যা হয়েছে: $e', isError: true)));
    } finally {
      _persist();
      if (mounted) setState(() => sending = false);
      _scrollDown();
    }
  }

  Widget _bubble(ChatMsg m) {
    final mine = m.role == 'user';
    final isImage = (m.attachMime ?? '').startsWith('image/') && m.attachBytes != null;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.88),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: mine ? const Color(0xFF51469A) : (m.isError ? const Color(0xFF3A1F2B) : const Color(0xFF171C2B)),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (isImage)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.memory(m.attachBytes!, height: 150, fit: BoxFit.cover),
                ),
              ),
            if (m.attachName != null && !isImage && m.text.isEmpty)
              Text('📎 ${m.attachName}'),
            if (m.text.isNotEmpty) mine ? SelectableText(m.text) : RichReply(m.text),
            for (final a in m.actions) ActionCard(action: a),
            if (m.needsKey)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: FilledButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const AiSettingsScreen()),
                  ),
                  child: const Text('API Key যোগ করুন'),
                ),
              ),
            if (!mine && !m.isError && !m.needsKey)
              Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  tooltip: 'Copy',
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: m.text));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('কপি হয়েছে')));
                  },
                  icon: const Icon(Icons.copy, color: Colors.white54),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  tooltip: 'শুনুন',
                  onPressed: () => speakText(tts, m.text),
                  icon: const Icon(Icons.volume_up_outlined, color: Colors.white54),
                ),
              ]),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Column(children: [
    AiStatusHeader(busy: sending),
    if (msgs.isNotEmpty)
      Align(
        alignment: Alignment.centerRight,
        child: TextButton.icon(
          onPressed: () {
            setState(() => msgs.clear());
            _persist();
          },
          icon: const Icon(Icons.add_comment_outlined, size: 18),
          label: const Text('নতুন চ্যাট'),
        ),
      ),
    Expanded(
      child: msgs.isEmpty
          ? Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    width: 92,
                    height: 92,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Color(0x408B7CFF), blurRadius: 40)],
                      gradient: RadialGradient(colors: [Color(0xFF51469A), Color(0xFF171B30)]),
                    ),
                    child: const Icon(Icons.auto_awesome, size: 42, color: Colors.white),
                  ),
                  const SizedBox(height: 24),
                  const Text('কীভাবে সাহায্য করতে পারি?', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text(
                    'প্রশ্ন করো, আইডিয়া দাও, পোস্ট লেখাও বা WhatsApp মেসেজ বানাও।',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54),
                  ),
                  const SizedBox(height: 20),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.center,
                    children: [
                      for (final s in _suggestions)
                        ActionChip(
                          label: Text(s),
                          onPressed: () {
                            controller.text = s;
                            send();
                          },
                        ),
                    ],
                  ),
                ]),
              ),
            )
          : ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.all(16),
              itemCount: msgs.length + (sending ? 1 : 0),
              itemBuilder: (context, i) {
                if (i == msgs.length) {
                  return const Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 10, left: 6),
                      child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)),
                    ),
                  );
                }
                return _bubble(msgs[i]);
              },
            ),
    ),
    if (_att != null)
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Align(
          alignment: Alignment.centerLeft,
          child: InputChip(
            avatar: const Icon(Icons.attach_file, size: 16),
            label: Text(_att!.name, overflow: TextOverflow.ellipsis),
            onDeleted: () => setState(() => _att = null),
          ),
        ),
      ),
    Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
      child: Row(children: [
        IconButton(onPressed: _attach, icon: const Icon(Icons.add_circle_outline)),
        Expanded(
          child: TextField(
            controller: controller,
            minLines: 1,
            maxLines: 5,
            textInputAction: TextInputAction.newline,
            decoration: const InputDecoration(hintText: 'Omor AI-কে কিছু জিজ্ঞেস করো...'),
          ),
        ),
        const SizedBox(width: 8),
        IconButton.filled(
          onPressed: sending ? null : send,
          icon: const Icon(Icons.arrow_upward),
        ),
      ]),
    ),
  ]);
}
