import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../services/actions.dart';
import '../services/ai_service.dart';
import '../services/app_state.dart';
import '../services/attachments.dart';
import '../widgets/common.dart';
import 'app_shell.dart';
import 'data_screens.dart';

class ToolConfig {
  const ToolConfig({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.system,
    required this.hint,
    this.search = false,
    this.image = false,
    this.file = false,
    this.chipsLabel = '',
    this.chips = const [],
    this.defaultPrompt = '',
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final String system;
  final String hint;
  final bool search;
  final bool image;
  final bool file;
  final String chipsLabel;
  final List<String> chips;
  final String defaultPrompt;
}

const toolConfigs = <ToolConfig>[
  ToolConfig(
    icon: Icons.search,
    title: 'Web Research',
    subtitle: 'Search and summarize trusted sources',
    hint: 'কী নিয়ে রিসার্চ করতে চাও?',
    search: true,
    system: 'You are a research assistant. Search the web, give a well-organised summary with the key facts, and mention source names. Say clearly if something is uncertain.',
  ),
  ToolConfig(
    icon: Icons.code,
    title: 'Code Assistant',
    subtitle: 'Write, explain and debug code',
    hint: 'কোড লেখো, এরর পেস্ট করো বা প্রশ্ন করো...',
    system: 'You are an expert programmer. Give correct, complete, runnable code in fenced code blocks, then a short explanation. When debugging, explain the cause of the bug first.',
  ),
  ToolConfig(
    icon: Icons.description_outlined,
    title: 'Document Reader',
    subtitle: 'Analyze PDF and text documents',
    hint: 'ডকুমেন্ট নিয়ে কী জানতে চাও? (খালি রাখলে সারাংশ দেবে)',
    file: true,
    defaultPrompt: 'এই ডকুমেন্টের একটা পরিষ্কার সারাংশ দাও, মূল পয়েন্টগুলো বুলেট আকারে।',
    system: 'You read documents carefully. Answer only from the document and quote nothing you cannot find in it.',
  ),
  ToolConfig(
    icon: Icons.image_outlined,
    title: 'Image Understanding',
    subtitle: 'Ask questions about an image or screenshot',
    hint: 'ছবি নিয়ে কী জানতে চাও?',
    image: true,
    defaultPrompt: 'এই ছবিতে কী আছে বিস্তারিত বলো। লেখা থাকলে সেটাও পড়ে শোনাও।',
    system: 'You analyze images and screenshots precisely. Read any text in the image and explain what it shows.',
  ),
  ToolConfig(
    icon: Icons.task_alt,
    title: 'Task Planner',
    subtitle: 'Break a goal into safe, reviewable steps',
    hint: 'তোমার লক্ষ্য বা কাজটা লেখো...',
    system: 'You are a practical planner. Break the goal into clear numbered steps with rough time estimates, and point out risks or things to check.',
  ),
  ToolConfig(
    icon: Icons.campaign_outlined,
    title: 'Post Creator',
    subtitle: 'Facebook, TikTok, Telegram পোস্ট বানাও',
    hint: 'পোস্টের বিষয় কী?',
    chipsLabel: 'প্ল্যাটফর্ম',
    chips: ['Facebook', 'TikTok', 'Instagram', 'Telegram', 'X (Twitter)'],
    system: 'You write social media posts. Write ONE ready-to-post version in the style of the chosen platform, with natural emojis and relevant hashtags. Write in the language of the request (Bangla by default). Output only the post.',
  ),
  ToolConfig(
    icon: Icons.translate,
    title: 'Translator',
    subtitle: 'Translate between languages',
    hint: 'অনুবাদ করার লেখা দাও...',
    chipsLabel: 'ভাষা',
    chips: ['বাংলা', 'English', 'हिन्दी', 'العربية'],
    system: 'You are a translator. Translate the text into the chosen language naturally. Output only the translation.',
  ),
];

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  @override
  Widget build(BuildContext context) => Column(children: [
    const PageHeader(subtitle: 'AI TOOLBOX'),
    Expanded(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        for (final c in toolConfigs)
          _ToolTile(
            icon: c.icon,
            title: c.title,
            subtitle: c.subtitle,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => ToolPage(cfg: c)),
            ),
          ),
        _ToolTile(
          icon: Icons.send_outlined,
          title: 'Send Message',
          subtitle: 'WhatsApp / SMS মেসেজ AI দিয়ে লিখে পাঠাও',
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const MessageToolPage()),
          ),
        ),
        _ToolTile(
          icon: Icons.memory,
          title: 'Memory Manager',
          subtitle: 'Review and control saved memories',
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const MemoryScreen()),
          ),
        ),
      ]),
    ),
  ]);
}

class _ToolTile extends StatelessWidget {
  const _ToolTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF141827),
    child: ListTile(
      onTap: onTap,
      leading: CircleAvatar(backgroundColor: const Color(0xFF302B59), child: Icon(icon, color: const Color(0xFFB8AEFF))),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54)),
      trailing: const Icon(Icons.chevron_right),
    ),
  );
}

class ToolPage extends StatefulWidget {
  const ToolPage({super.key, required this.cfg});
  final ToolConfig cfg;
  @override
  State<ToolPage> createState() => _ToolPageState();
}

class _ToolPageState extends State<ToolPage> {
  final ctl = TextEditingController();
  Attachment? att;
  int chip = 0;
  String output = '';
  String error = '';
  bool loading = false;

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _snack(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _pick() async {
    Attachment? a;
    try {
      if (widget.cfg.file) {
        a = await pickFileAttachment();
      } else {
        final src = await showModalBottomSheet<ImageSource>(
          context: context,
          builder: (c) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(leading: const Icon(Icons.photo_outlined), title: const Text('গ্যালারি'), onTap: () => Navigator.pop(c, ImageSource.gallery)),
              ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('ক্যামেরা'), onTap: () => Navigator.pop(c, ImageSource.camera)),
            ]),
          ),
        );
        if (src == null) return;
        a = await pickImageAttachment(src);
      }
    } catch (_) {
      if (mounted) _snack('ফাইল নেওয়া যায়নি');
    }
    if (a != null && mounted) setState(() => att = a);
  }

  Future<void> _run() async {
    final c = widget.cfg;
    final a = att;
    var text = ctl.text.trim();
    if (text.isEmpty) text = c.defaultPrompt;
    if ((c.file || c.image) && a == null) {
      _snack(c.file ? 'আগে একটা ফাইল বেছে নাও' : 'আগে একটা ছবি বেছে নাও');
      return;
    }
    if (text.isEmpty) {
      _snack('কিছু লেখো');
      return;
    }
    final b = StringBuffer();
    if (c.chips.isNotEmpty) b.writeln('${c.chipsLabel}: ${c.chips[chip]}');
    final aText = a?.text;
    if (aText != null) b.writeln(aText);
    b.write(text);
    setState(() {
      loading = true;
      error = '';
      output = '';
    });
    try {
      final raw = await AiService.ask(
        [AiMessage('user', b.toString(), data: a?.bytes, mime: a?.mime)],
        system: '${buildSystemPrompt(actions: false)}\n${c.system}',
        search: c.search && appState.webSearch,
      );
      final out = parseReply(raw).text;
      if (mounted) setState(() => output = out);
    } on AiException catch (e) {
      if (mounted) {
        setState(() => error = e.message == AiService.noKey
            ? 'আগে Settings → AI Providers & Keys এ API key দিন।'
            : e.message);
      }
    } catch (e) {
      if (mounted) setState(() => error = 'সমস্যা হয়েছে: $e');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.cfg;
    final a = att;
    return Scaffold(
      appBar: AppBar(title: Text(c.title), backgroundColor: const Color(0xFF090B14)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(c.subtitle, style: const TextStyle(color: Colors.white54)),
        const SizedBox(height: 14),
        if (c.chips.isNotEmpty) ...[
          Text(c.chipsLabel, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < c.chips.length; i++)
              ChoiceChip(
                label: Text(c.chips[i]),
                selected: chip == i,
                onSelected: (_) => setState(() => chip = i),
              ),
          ]),
          const SizedBox(height: 14),
        ],
        if (c.file || c.image) ...[
          OutlinedButton.icon(
            onPressed: _pick,
            icon: Icon(c.file ? Icons.attach_file : Icons.add_photo_alternate_outlined),
            label: Text(a == null ? (c.file ? 'ফাইল বেছে নাও' : 'ছবি বেছে নাও') : a.name, overflow: TextOverflow.ellipsis),
          ),
          if (a != null && a.bytes != null && (a.mime ?? '').startsWith('image/'))
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.memory(a.bytes!, height: 160, fit: BoxFit.cover),
              ),
            ),
          const SizedBox(height: 14),
        ],
        TextField(
          controller: ctl,
          minLines: 3,
          maxLines: 8,
          decoration: InputDecoration(hintText: c.hint),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: loading ? null : _run,
          icon: loading
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.auto_awesome),
          label: Text(loading ? 'কাজ চলছে...' : 'চালাও'),
        ),
        if (error.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Text(error, style: const TextStyle(color: Color(0xFFFF8A9B))),
          ),
        if (output.isNotEmpty) ...[
          const SizedBox(height: 16),
          Card(
            color: const Color(0xFF141827),
            child: Padding(padding: const EdgeInsets.all(16), child: RichReply(output)),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            TextButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: output));
                _snack('কপি হয়েছে');
              },
              icon: const Icon(Icons.copy, size: 18),
              label: const Text('Copy'),
            ),
            TextButton.icon(
              onPressed: () => Share.share(output),
              icon: const Icon(Icons.share, size: 18),
              label: const Text('Share'),
            ),
          ]),
        ],
      ]),
    );
  }
}

class MessageToolPage extends StatefulWidget {
  const MessageToolPage({super.key});
  @override
  State<MessageToolPage> createState() => _MessageToolPageState();
}

class _MessageToolPageState extends State<MessageToolPage> {
  final toCtl = TextEditingController();
  final instrCtl = TextEditingController();
  final draftCtl = TextEditingController();
  String channel = 'whatsapp';
  bool loading = false;
  String error = '';

  @override
  void dispose() {
    toCtl.dispose();
    instrCtl.dispose();
    draftCtl.dispose();
    super.dispose();
  }

  Future<void> _draft() async {
    final instr = instrCtl.text.trim();
    if (instr.isEmpty) return;
    setState(() {
      loading = true;
      error = '';
    });
    try {
      final raw = await AiService.ask(
        [AiMessage('user', 'প্রাপক: ${toCtl.text.trim()}\nআমি যা বলতে চাই: $instr')],
        system: 'Write one short, natural message that the user will send to the recipient. Use the language and tone that fit the instruction (Bangla by default). Output ONLY the message text, nothing else.',
      );
      if (mounted) setState(() => draftCtl.text = parseReply(raw).text);
    } on AiException catch (e) {
      if (mounted) {
        setState(() => error = e.message == AiService.noKey
            ? 'আগে Settings → AI Providers & Keys এ API key দিন।'
            : e.message);
      }
    } catch (e) {
      if (mounted) setState(() => error = 'সমস্যা হয়েছে: $e');
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _open() async {
    final err = await runAction(AiAction(channel, {
      'type': channel,
      'to': toCtl.text.trim(),
      'text': draftCtl.text.trim(),
    }));
    if (err != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Send Message'), backgroundColor: const Color(0xFF090B14)),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text(
        'কাকে পাঠাবে (Contacts এ সেভ করা নাম বা নম্বর) আর কী বলতে চাও লেখো। AI মেসেজ লিখে দেবে, তারপর তুমি নিজে Send চাপবে।',
        style: TextStyle(color: Colors.white54),
      ),
      const SizedBox(height: 14),
      TextField(
        controller: toCtl,
        decoration: const InputDecoration(hintText: 'নাম বা নম্বর (যেমন: রহিম / 017XXXXXXXX)'),
      ),
      const SizedBox(height: 12),
      Wrap(spacing: 8, children: [
        ChoiceChip(label: const Text('WhatsApp'), selected: channel == 'whatsapp', onSelected: (_) => setState(() => channel = 'whatsapp')),
        ChoiceChip(label: const Text('SMS'), selected: channel == 'sms', onSelected: (_) => setState(() => channel = 'sms')),
      ]),
      const SizedBox(height: 12),
      TextField(
        controller: instrCtl,
        minLines: 2,
        maxLines: 5,
        decoration: const InputDecoration(hintText: 'কী বলতে চাও? যেমন: আজ সন্ধ্যায় দেখা হবে কি না জিজ্ঞেস করো'),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: loading ? null : _draft,
        icon: loading
            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.auto_awesome),
        label: const Text('মেসেজ লিখে দাও'),
      ),
      if (error.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(error, style: const TextStyle(color: Color(0xFFFF8A9B))),
        ),
      const SizedBox(height: 16),
      TextField(
        controller: draftCtl,
        minLines: 3,
        maxLines: 8,
        decoration: const InputDecoration(hintText: 'মেসেজের খসড়া এখানে আসবে (এডিট করতে পারবে)'),
      ),
      const SizedBox(height: 12),
      FilledButton.tonalIcon(
        onPressed: _open,
        icon: Icon(channel == 'whatsapp' ? Icons.chat : Icons.sms_outlined),
        label: Text(channel == 'whatsapp' ? 'WhatsApp এ খোলো' : 'SMS অ্যাপে খোলো'),
      ),
    ]),
  );
}
