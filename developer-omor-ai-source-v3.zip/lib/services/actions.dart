import 'dart:convert';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_state.dart';

class AiAction {
  AiAction(this.type, this.data);
  final String type;
  final Map<String, dynamic> data;
  String get to => (data['to'] ?? '').toString();
  String get text => (data['text'] ?? '').toString();
  String get url => (data['url'] ?? data['to'] ?? '').toString();
}

class ParsedReply {
  ParsedReply(this.text, this.actions);
  final String text;
  final List<AiAction> actions;
}

final _actionRe = RegExp(r'\[\[ACTION\s*(\{.*?\})\s*\]\]', dotAll: true);
final _memoryRe = RegExp(r'\[\[MEMORY\s+(.*?)\]\]', dotAll: true);

/// Splits a raw model reply into visible text, confirmable actions and auto-saved memories.
ParsedReply parseReply(String raw) {
  final actions = <AiAction>[];
  for (final m in _actionRe.allMatches(raw)) {
    try {
      final j = jsonDecode(m.group(1)!) as Map<String, dynamic>;
      actions.add(AiAction((j['type'] ?? '').toString(), j));
    } catch (_) {}
  }
  for (final m in _memoryRe.allMatches(raw)) {
    final fact = (m.group(1) ?? '').trim();
    if (fact.isNotEmpty && !appState.memories.contains(fact)) {
      appState.addMemory(fact);
    }
  }
  final text = raw.replaceAll(_actionRe, '').replaceAll(_memoryRe, '').trim();
  return ParsedReply(text, actions);
}

String? _resolvePhone(String to) {
  final compact = to.replaceAll(RegExp(r'[\s\-()]'), '');
  if (RegExp(r'^\+?[0-9]{7,15}$').hasMatch(compact)) return compact;
  final q = to.trim().toLowerCase();
  if (q.isEmpty) return null;
  for (final c in appState.contacts) {
    final n = (c['name'] ?? '').toLowerCase();
    if (n.isNotEmpty && (n.contains(q) || q.contains(n))) return c['phone'];
  }
  return null;
}

String _waNumber(String phone) {
  var d = phone.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00')) {
    d = d.substring(2);
  } else if (d.startsWith('01') && d.length == 11) {
    d = '88$d';
  }
  return d;
}

Future<String?> _launch(Uri uri) async {
  try {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    return ok ? null : 'অ্যাপ খোলা যায়নি';
  } catch (_) {
    return 'অ্যাপ খোলা যায়নি';
  }
}

/// Runs an action after the user confirmed it. Returns an error message, or null on success.
Future<String?> runAction(AiAction a) async {
  switch (a.type) {
    case 'whatsapp':
    case 'sms':
    case 'call':
      final phone = _resolvePhone(a.to);
      if (phone == null) {
        return '"${a.to}" নামে কন্টাক্ট পাওয়া যায়নি। Settings > Contacts এ নাম ও নম্বর যোগ করুন।';
      }
      final Uri uri;
      if (a.type == 'whatsapp') {
        uri = Uri.parse('https://wa.me/${_waNumber(phone)}?text=${Uri.encodeComponent(a.text)}');
      } else if (a.type == 'sms') {
        uri = Uri.parse('sms:$phone?body=${Uri.encodeComponent(a.text)}');
      } else {
        uri = Uri.parse('tel:$phone');
      }
      return _launch(uri);
    case 'telegram':
      final tgUser = a.to.replaceAll('@', '').trim();
      if (tgUser.isEmpty) return 'Telegram ইউজারনেম নেই';
      return _launch(Uri.parse('https://t.me/$tgUser'));
    case 'open_url':
      final link = a.url.trim();
      if (link.isEmpty) return 'লিংক নেই';
      return _launch(Uri.parse(link.startsWith('http') ? link : 'https://$link'));
    case 'share':
      await Share.share(a.text);
      return null;
    default:
      return 'অজানা অ্যাকশন: ${a.type}';
  }
}
