import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProviderDef {
  const ProviderDef({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.defaultModel,
    required this.hint,
  });
  final String id;
  final String name;
  final String baseUrl;
  final String defaultModel;
  final String hint;
}

const providerList = <ProviderDef>[
  ProviderDef(
    id: 'gemini',
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: 'gemini-2.5-flash',
    hint: 'ফ্রি key: aistudio.google.com/apikey',
  ),
  ProviderDef(
    id: 'groq',
    name: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    hint: 'ফ্রি key: console.groq.com/keys',
  ),
  ProviderDef(
    id: 'openrouter',
    name: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: 'meta-llama/llama-3.3-70b-instruct:free',
    hint: 'ফ্রি মডেল আছে: openrouter.ai/keys',
  ),
  ProviderDef(
    id: 'xai',
    name: 'xAI Grok',
    baseUrl: 'https://api.x.ai/v1',
    defaultModel: 'grok-3-mini',
    hint: 'console.x.ai',
  ),
  ProviderDef(
    id: 'custom',
    name: 'Custom (OpenAI-compatible)',
    baseUrl: '',
    defaultModel: '',
    hint: 'যেকোনো OpenAI-compatible সার্ভিস (Base URL + Model দিন)',
  ),
];

ProviderDef providerById(String id) =>
    providerList.firstWhere((p) => p.id == id, orElse: () => providerList.first);

class AppState extends ChangeNotifier {
  SharedPreferences? _prefs;
  String preferred = 'gemini';
  String language = 'auto';
  String userName = '';
  bool webSearch = true;
  String customBase = '';
  int chatResets = 0;
  final Map<String, String> keys = {};
  final Map<String, String> models = {};
  List<String> memories = [];
  List<Map<String, String>> contacts = [];
  List<Map<String, String>> chat = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _prefs = p;
    preferred = p.getString('preferred') ?? 'gemini';
    language = p.getString('language') ?? 'auto';
    userName = p.getString('userName') ?? '';
    webSearch = p.getBool('webSearch') ?? true;
    customBase = p.getString('customBase') ?? '';
    for (final d in providerList) {
      keys[d.id] = p.getString('key_${d.id}') ?? '';
      models[d.id] = p.getString('model_${d.id}') ?? '';
    }
    memories = p.getStringList('memories') ?? <String>[];
    contacts = _decodeList(p.getString('contacts'));
    chat = _decodeList(p.getString('chat'));
  }

  List<Map<String, String>> _decodeList(String? raw) {
    if (raw == null || raw.isEmpty) return <Map<String, String>>[];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => Map<String, String>.from(e as Map)).toList();
    } catch (_) {
      return <Map<String, String>>[];
    }
  }

  bool get hasAnyKey => keys.values.any((v) => v.trim().isNotEmpty);

  String modelFor(String id) {
    final m = (models[id] ?? '').trim();
    return m.isEmpty ? providerById(id).defaultModel : m;
  }

  Future<void> setKey(String id, String v) async {
    keys[id] = v.trim();
    await _prefs?.setString('key_$id', v.trim());
    notifyListeners();
  }

  Future<void> setModel(String id, String v) async {
    models[id] = v.trim();
    await _prefs?.setString('model_$id', v.trim());
  }

  Future<void> setCustomBase(String v) async {
    customBase = v.trim();
    await _prefs?.setString('customBase', customBase);
  }

  Future<void> setPreferred(String id) async {
    preferred = id;
    await _prefs?.setString('preferred', id);
    notifyListeners();
  }

  Future<void> setLanguage(String v) async {
    language = v;
    await _prefs?.setString('language', v);
    notifyListeners();
  }

  Future<void> setUserName(String v) async {
    userName = v.trim();
    await _prefs?.setString('userName', userName);
  }

  Future<void> setWebSearch(bool v) async {
    webSearch = v;
    await _prefs?.setBool('webSearch', v);
    notifyListeners();
  }

  Future<void> addMemory(String fact) async {
    memories = [...memories, fact];
    await _prefs?.setStringList('memories', memories);
    notifyListeners();
  }

  Future<void> removeMemory(int index) async {
    if (index < 0 || index >= memories.length) return;
    memories = [...memories]..removeAt(index);
    await _prefs?.setStringList('memories', memories);
    notifyListeners();
  }

  Future<void> addContact(String name, String phone) async {
    contacts = [
      ...contacts,
      {'name': name.trim(), 'phone': phone.trim()},
    ];
    await _prefs?.setString('contacts', jsonEncode(contacts));
    notifyListeners();
  }

  Future<void> removeContact(int index) async {
    if (index < 0 || index >= contacts.length) return;
    contacts = [...contacts]..removeAt(index);
    await _prefs?.setString('contacts', jsonEncode(contacts));
    notifyListeners();
  }

  Future<void> saveChat(List<Map<String, String>> list) async {
    chat = list.length > 100 ? list.sublist(list.length - 100) : list;
    await _prefs?.setString('chat', jsonEncode(chat));
  }

  Future<void> clearChat() async {
    chat = <Map<String, String>>[];
    chatResets++;
    await _prefs?.setString('chat', jsonEncode(chat));
    notifyListeners();
  }
}

final appState = AppState();
