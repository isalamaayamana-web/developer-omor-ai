import 'package:flutter_tts/flutter_tts.dart';

Future<void> speakText(FlutterTts tts, String text) async {
  final clean = text.replaceAll(RegExp(r'[*#`_]'), '').trim();
  if (clean.isEmpty) return;
  final bn = RegExp(r'[\u0980-\u09FF]').hasMatch(clean);
  await tts.setLanguage(bn ? 'bn-BD' : 'en-US');
  await tts.setSpeechRate(0.5);
  await tts.speak(clean);
}
