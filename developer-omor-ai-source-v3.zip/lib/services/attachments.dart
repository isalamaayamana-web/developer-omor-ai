import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';

class Attachment {
  Attachment({required this.name, this.bytes, this.mime, this.text});
  final String name;
  final Uint8List? bytes; // image or pdf
  final String? mime;
  final String? text; // text file content
}

String _imageMime(String path) {
  final p = path.toLowerCase();
  if (p.endsWith('.png')) return 'image/png';
  if (p.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
}

Future<Attachment?> pickImageAttachment(ImageSource source) async {
  final x = await ImagePicker().pickImage(source: source, maxWidth: 1600, imageQuality: 85);
  if (x == null) return null;
  final bytes = await x.readAsBytes();
  return Attachment(
    name: x.name,
    bytes: bytes,
    mime: _imageMime(x.path.isNotEmpty ? x.path : x.name),
  );
}

Future<Attachment?> pickFileAttachment() async {
  final r = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: ['pdf', 'txt', 'md', 'csv', 'json'],
    withData: true,
  );
  if (r == null || r.files.isEmpty) return null;
  final f = r.files.first;
  final bytes = f.bytes;
  if (bytes == null) return null;
  if ((f.extension ?? '').toLowerCase() == 'pdf') {
    return Attachment(name: f.name, bytes: bytes, mime: 'application/pdf');
  }
  var t = utf8.decode(bytes, allowMalformed: true);
  if (t.length > 30000) t = t.substring(0, 30000);
  return Attachment(name: f.name, text: '[ফাইল: ${f.name}]\n$t');
}
