import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'app_state.dart';

class AiMessage {
  AiMessage(this.role, this.text, {this.data, this.mime});
  final String role; // 'user' or 'assistant'
  final String text;
  final Uint8List? data;
  final String? mime;
}

class AiException implements Exception {
  AiException(this.message);
  final String message;
  @override
  String toString() => message;
}

const _actionHelp = '''
You can help the user act on their phone. When (and only when) the user asks for one of these, write a short normal reply AND add one line at the very end in exactly this format (the app shows a confirm button; you cannot send anything yourself):
[[ACTION {"type":"whatsapp","to":"<saved contact name or phone number with country code>","text":"<message>"}]]
Types: whatsapp and sms (fields: to, text), call (field: to), telegram (field: to = username), share (field: text = a ready-to-post social media post), open_url (field: url).
For post requests, write the full post in your reply and also add a share action with the same text.
If the user asks you to remember something about them, add [[MEMORY <short fact>]] at the end.
You cannot see the phone screen; if the user needs help with something on their screen, ask them to attach a screenshot.
Never claim a message was already sent; say it is ready for the user to confirm.''';

String buildSystemPrompt({bool actions = true}) {
  final b = StringBuffer();
  b.writeln('You are DEVELOPER OMOR AI, a smart, friendly personal AI assistant created by Omor.');
  if (appState.userName.isNotEmpty) {
    b.writeln("The user's name is ${appState.userName}.");
  }
  switch (appState.language) {
    case 'bn':
      b.writeln('Always reply in Bangla (Bengali) unless the user clearly asks for another language.');
      break;
    case 'en':
      b.writeln('Always reply in English unless the user clearly asks for another language.');
      break;
    default:
      b.writeln('Reply in the same language the user writes in. If they write Bangla (or Banglish), reply in Bangla.');
  }
  b.writeln('Be accurate, clear and concise. Use short paragraphs and simple lists. Never invent facts; say when you are unsure.');
  if (appState.memories.isNotEmpty) {
    b.writeln('Things you know about the user:');
    for (final m in appState.memories) {
      b.writeln('- $m');
    }
  }
  b.writeln('Current date and time: ${DateTime.now()}');
  if (actions) b.writeln(_actionHelp);
  return b.toString();
}

class AiService {
  static const noKey = 'NO_KEY';

  /// Tries the preferred provider first, then falls back to any other provider that has a key.
  static Future<String> ask(
    List<AiMessage> messages, {
    String? system,
    bool search = false,
  }) async {
    final order = <String>[
      appState.preferred,
      ...providerList.map((p) => p.id).where((id) => id != appState.preferred),
    ];
    final errors = <String>[];
    for (final id in order) {
      final key = (appState.keys[id] ?? '').trim();
      if (key.isEmpty) continue;
      try {
        final out = id == 'gemini'
            ? await _gemini(key, messages, system, search)
            : await _compat(id, key, messages, system);
        if (out.trim().isNotEmpty) return out;
        errors.add('${providerById(id).name}: খালি উত্তর');
      } on AiException catch (e) {
        errors.add('${providerById(id).name}: ${e.message}');
      } catch (e) {
        errors.add('${providerById(id).name}: সংযোগ সমস্যা (ইন্টারনেট চেক করুন)');
      }
    }
    if (errors.isEmpty) throw AiException(noKey);
    throw AiException(errors.join('\n'));
  }

  static String _errorText(http.Response r) {
    try {
      final d = jsonDecode(utf8.decode(r.bodyBytes));
      if (d is Map && d['error'] is Map && (d['error'] as Map)['message'] != null) {
        return '${r.statusCode} ${(d['error'] as Map)['message']}';
      }
      if (d is Map && d['error'] is String) return '${r.statusCode} ${d['error']}';
    } catch (_) {}
    return 'HTTP ${r.statusCode}';
  }

  static Future<String> _gemini(
    String key,
    List<AiMessage> messages,
    String? system,
    bool search,
  ) async {
    final model = appState.modelFor('gemini');
    final uri = Uri.parse('${providerById('gemini').baseUrl}/models/$model:generateContent');
    final contents = <Map<String, dynamic>>[];
    for (final m in messages) {
      final parts = <Map<String, dynamic>>[];
      if (m.data != null) {
        parts.add({
          'inlineData': {
            'mimeType': m.mime ?? 'image/jpeg',
            'data': base64Encode(m.data!),
          },
        });
      }
      parts.add({'text': m.text.trim().isEmpty ? '.' : m.text});
      contents.add({'role': m.role == 'user' ? 'user' : 'model', 'parts': parts});
    }
    final body = <String, dynamic>{'contents': contents};
    if (system != null) {
      body['systemInstruction'] = {
        'parts': [
          {'text': system},
        ],
      };
    }
    if (search) {
      body['tools'] = [
        {'google_search': <String, dynamic>{}},
      ];
    }
    final r = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json', 'x-goog-api-key': key},
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 90));
    if (r.statusCode == 400 && search) {
      return _gemini(key, messages, system, false);
    }
    if (r.statusCode != 200) throw AiException(_errorText(r));
    final d = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    final cands = d['candidates'];
    if (cands is! List || cands.isEmpty) {
      throw AiException('খালি উত্তর (সেফটি ফিল্টার হতে পারে)');
    }
    final content = (cands.first as Map)['content'];
    if (content is! Map) return '';
    final parts = content['parts'];
    if (parts is! List) return '';
    return parts.map((p) => (p is Map ? (p['text'] ?? '') : '').toString()).join();
  }

  static Future<String> _compat(
    String id,
    String key,
    List<AiMessage> messages,
    String? system,
  ) async {
    final def = providerById(id);
    var base = id == 'custom' ? appState.customBase.trim() : def.baseUrl;
    if (base.isEmpty) throw AiException('Base URL দেওয়া হয়নি');
    while (base.endsWith('/')) {
      base = base.substring(0, base.length - 1);
    }
    final model = appState.modelFor(id);
    if (model.isEmpty) throw AiException('Model নাম দেওয়া হয়নি');
    final msgs = <Map<String, dynamic>>[];
    if (system != null) msgs.add({'role': 'system', 'content': system});
    for (final m in messages) {
      if (m.data != null) {
        if ((m.mime ?? '').startsWith('image/')) {
          msgs.add({
            'role': m.role,
            'content': [
              {'type': 'text', 'text': m.text},
              {
                'type': 'image_url',
                'image_url': {'url': 'data:${m.mime};base64,${base64Encode(m.data!)}'},
              },
            ],
          });
        } else {
          throw AiException('PDF শুধু Gemini দিয়ে পড়া যায়');
        }
      } else {
        msgs.add({'role': m.role, 'content': m.text});
      }
    }
    final r = await http
        .post(
          Uri.parse('$base/chat/completions'),
          headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $key'},
          body: jsonEncode({'model': model, 'messages': msgs}),
        )
        .timeout(const Duration(seconds: 90));
    if (r.statusCode != 200) throw AiException(_errorText(r));
    final d = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    final choices = d['choices'];
    if (choices is! List || choices.isEmpty) throw AiException('খালি উত্তর');
    final msg = (choices.first as Map)['message'];
    final c = msg is Map ? msg['content'] : null;
    return c?.toString() ?? '';
  }
}
