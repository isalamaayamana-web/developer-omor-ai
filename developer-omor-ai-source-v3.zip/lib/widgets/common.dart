import 'package:flutter/material.dart';
import '../services/actions.dart';

TextSpan _inline(String line) {
  final re = RegExp(r'\*\*(.+?)\*\*|`([^`]+)`');
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in re.allMatches(line)) {
    if (m.start > last) spans.add(TextSpan(text: line.substring(last, m.start)));
    if (m.group(1) != null) {
      spans.add(TextSpan(text: m.group(1), style: const TextStyle(fontWeight: FontWeight.w700)));
    } else {
      spans.add(TextSpan(
        text: m.group(2),
        style: const TextStyle(fontFamily: 'monospace', backgroundColor: Color(0x33FFFFFF)),
      ));
    }
    last = m.end;
  }
  if (last < line.length) spans.add(TextSpan(text: line.substring(last)));
  return TextSpan(children: spans);
}

/// Small markdown-ish renderer: headings, bullets, **bold**, `code` and code blocks.
class RichReply extends StatelessWidget {
  const RichReply(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    final spans = <InlineSpan>[];
    void add(InlineSpan s) {
      if (spans.isNotEmpty) spans.add(const TextSpan(text: '\n'));
      spans.add(s);
    }

    var inCode = false;
    for (final raw in text.trim().split('\n')) {
      if (raw.trimLeft().startsWith('```')) {
        inCode = !inCode;
        continue;
      }
      if (inCode) {
        add(TextSpan(
          text: raw,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Color(0xFFB8F5E6)),
        ));
        continue;
      }
      final h = RegExp(r'^#{1,6}\s+(.*)$').firstMatch(raw);
      if (h != null) {
        add(TextSpan(
          text: h.group(1),
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ));
        continue;
      }
      final line = raw.replaceFirstMapped(RegExp(r'^(\s*)[*-]\s+'), (m) => '${m.group(1)}• ');
      add(_inline(line));
    }
    return SelectableText.rich(
      TextSpan(children: spans),
      style: const TextStyle(height: 1.45),
    );
  }
}

class ActionCard extends StatefulWidget {
  const ActionCard({super.key, required this.action});
  final AiAction action;
  @override
  State<ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends State<ActionCard> {
  bool done = false;

  (IconData, String) get _info {
    switch (widget.action.type) {
      case 'whatsapp':
        return (Icons.chat, 'WhatsApp মেসেজ');
      case 'sms':
        return (Icons.sms_outlined, 'SMS');
      case 'call':
        return (Icons.call, 'কল');
      case 'telegram':
        return (Icons.send, 'Telegram');
      case 'share':
        return (Icons.share, 'পোস্ট / শেয়ার');
      case 'open_url':
        return (Icons.open_in_browser, 'লিংক খোলো');
      default:
        return (Icons.bolt, widget.action.type);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.action;
    final info = _info;
    return Card(
      color: const Color(0xFF1F2540),
      margin: const EdgeInsets.only(top: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(info.$1, size: 18, color: const Color(0xFFB8AEFF)),
              const SizedBox(width: 8),
              Text(info.$2, style: const TextStyle(fontWeight: FontWeight.w700)),
            ]),
            if (a.to.isNotEmpty && a.type != 'open_url')
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('প্রাপক: ${a.to}', style: const TextStyle(color: Colors.white70)),
              ),
            if (a.text.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(a.text, maxLines: 5, overflow: TextOverflow.ellipsis),
              ),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.tonalIcon(
                onPressed: () async {
                  final err = await runAction(a);
                  if (!mounted) return;
                  if (err != null) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
                  } else {
                    setState(() => done = true);
                  }
                },
                icon: Icon(done ? Icons.check : Icons.play_arrow),
                label: Text(done ? 'আবার খোলো' : 'চালু করো'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
